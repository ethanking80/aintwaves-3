-- AIRWAVES Database Schema for Neon PostgreSQL
-- Run this in your Neon database console to set up the tables

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    thc VARCHAR(20),
    cbd VARCHAR(20),
    weight VARCHAR(50),
    description TEXT,
    stock INTEGER DEFAULT 0,
    featured BOOLEAN DEFAULT FALSE,
    image TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    icon VARCHAR(10)
);

-- Customers table
CREATE TABLE IF NOT EXISTS customers (
    id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255),
    phone VARCHAR(50),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(50),
    zip VARCHAR(20),
    age_verified BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sessions table (for auth)
CREATE TABLE IF NOT EXISTS sessions (
    id VARCHAR(100) PRIMARY KEY,
    customer_id VARCHAR(50),
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP
);

-- Cart items table
CREATE TABLE IF NOT EXISTS cart_items (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    product_id INTEGER REFERENCES products(id),
    quantity INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(session_id, product_id)
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id VARCHAR(50) PRIMARY KEY,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id VARCHAR(50) REFERENCES customers(id),
    customer_name VARCHAR(255),
    customer_email VARCHAR(255),
    customer_phone VARCHAR(50),
    shipping_address TEXT,
    shipping_city VARCHAR(100),
    shipping_state VARCHAR(50),
    shipping_zip VARCHAR(20),
    subtotal DECIMAL(10,2),
    shipping DECIMAL(10,2),
    tax DECIMAL(10,2),
    total DECIMAL(10,2),
    shipping_type VARCHAR(100),
    payment_method VARCHAR(100),
    payment_status VARCHAR(50) DEFAULT 'pending',
    crypto_coin VARCHAR(10),
    status VARCHAR(50) DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
    id SERIAL PRIMARY KEY,
    order_id VARCHAR(50) REFERENCES orders(id),
    product_id INTEGER,
    product_name VARCHAR(255),
    product_price DECIMAL(10,2),
    quantity INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inventory locks table (for purchase queue)
CREATE TABLE IF NOT EXISTS inventory_locks (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    product_id INTEGER REFERENCES products(id),
    quantity INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP
);

-- Settings table
CREATE TABLE IF NOT EXISTS settings (
    key VARCHAR(100) PRIMARY KEY,
    value TEXT
);

-- Insert default categories
INSERT INTO categories (id, name, icon) VALUES
    ('all', 'All Products', '✦'),
    ('flower', 'Flower', '🌿'),
    ('edibles', 'Edibles', '🍬'),
    ('prerolls', 'Pre-Rolls', '🔥'),
    ('carts', 'Carts', '💨')
ON CONFLICT (id) DO NOTHING;

-- Insert default settings
INSERT INTO settings (key, value) VALUES
    ('free_shipping_threshold', '75'),
    ('tax_rate', '0.0625'),
    ('wallet_btc', ''),
    ('wallet_xmr', ''),
    ('wallet_ltc', '')
ON CONFLICT (key) DO NOTHING;

-- Insert sample products
INSERT INTO products (name, category, price, thc, cbd, weight, description, stock, featured) VALUES
    ('OG Kush Premium Flower', 'flower', 45.00, '22%', '0.5%', '3.5g', 'Classic indica-dominant hybrid with earthy pine notes.', 50, true),
    ('Sour Diesel Sativa', 'flower', 42.00, '24%', '0.3%', '3.5g', 'Energizing sativa with cerebral effects.', 35, false),
    ('Wedding Cake', 'flower', 48.00, '25%', '0.4%', '3.5g', 'Rich and tangy with pepper undertones.', 28, true),
    ('Blue Dream', 'flower', 40.00, '21%', '0.2%', '3.5g', 'Balanced hybrid with sweet berry aroma.', 42, false),
    ('Purple Haze', 'flower', 44.00, '20%', '0.3%', '3.5g', 'Legendary sativa with dreamy euphoria.', 38, false),
    ('Gummy Bears 10pk', 'edibles', 25.00, '100mg', '0mg', '10pk', 'Classic gummy bears, 10mg each.', 80, true),
    ('Chocolate Bar', 'edibles', 30.00, '200mg', '50mg', '100g', 'Premium dark chocolate with precise dosing.', 55, false),
    ('CBD Gummies', 'edibles', 35.00, '0mg', '500mg', '20pk', 'THC-free gummies for daily calm.', 65, false),
    ('Sour Worms', 'edibles', 28.00, '150mg', '0mg', '10pk', 'Tangy sour gummy worms.', 70, false),
    ('OG Kush Pre-Roll 5pk', 'prerolls', 35.00, '22%', '0.5%', '5x0.5g', 'Perfectly rolled, ready to enjoy.', 45, false),
    ('Variety Pack Pre-Rolls', 'prerolls', 55.00, 'Mixed', 'Mixed', '6x0.75g', 'Six strains sampler pack.', 30, true),
    ('Sativa Singles 3pk', 'prerolls', 22.00, '23%', '0.2%', '3x0.5g', 'Three energizing sativa pre-rolls.', 50, false),
    ('Live Resin Cart', 'carts', 50.00, '85%', '2%', '1g', 'Premium live resin for authentic flavor.', 40, true),
    ('Distillate Cart', 'carts', 35.00, '90%', '0%', '1g', 'Pure distillate with high potency.', 55, false),
    ('CBD Cart', 'carts', 40.00, '0%', '500mg', '0.5g', 'THC-free CBD cartridge for relaxation.', 45, false),
    ('Hybrid Blend Cart', 'carts', 45.00, '80%', '5%', '1g', 'Balanced hybrid blend for any occasion.', 35, false)
ON CONFLICT DO NOTHING;

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES products(id) ON DELETE CASCADE,
    customer_id VARCHAR(50) REFERENCES customers(id),
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    review_text TEXT,
    verified_purchase BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Order status history table for tracking all changes
CREATE TABLE IF NOT EXISTS order_status_history (
    id SERIAL PRIMARY KEY,
    order_id VARCHAR(50) REFERENCES orders(id) ON DELETE CASCADE,
    status VARCHAR(50) NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_cart_session ON cart_items(session_id);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_locks_session ON inventory_locks(session_id);
CREATE INDEX IF NOT EXISTS idx_locks_expires ON inventory_locks(expires_at);
CREATE INDEX IF NOT EXISTS idx_reviews_product ON reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_order_history ON order_status_history(order_id);
