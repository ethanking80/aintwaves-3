# AIRWAVES Deployment

## STEP 1: Deploy to Netlify

1. Extract this zip file
2. Go to Netlify → Your site → Deploys  
3. **IMPORTANT**: Open the extracted folder, select ALL files inside (Ctrl+A), drag to Netlify
   - Do NOT drag the folder itself - drag the CONTENTS

## STEP 2: Set Up Database

1. Go to neon.tech and create a new project
2. Copy the **Connection String** from Neon (Connection Details page)
3. In Netlify → Site configuration → Environment variables
4. Add: Key = `DATABASE_URL`, Value = your connection string
5. In Neon SQL Editor, paste and run the entire schema.sql

## STEP 3: Redeploy

After adding the environment variable, trigger a redeploy in Netlify.

## STEP 4: Test

- Store: https://your-site.netlify.app
- Admin: https://your-site.netlify.app/admin.html
  - Username: admin
  - Password: airwaves1

## File Structure:

```
netlify.toml        ← Config
package.json        ← Dependencies  
schema.sql          ← Database setup (run in Neon)
public/
  index.html        ← Store
  admin.html        ← Admin dashboard
  logo.jpg          ← Logo
netlify/
  functions/
    api.js          ← API code
```
